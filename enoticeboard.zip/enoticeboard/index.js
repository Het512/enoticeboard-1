const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors'); // Import cors package
const mysql = require('mysql'); // Import MySQL package

const app = express();
const port = 3000;

// Create MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Replace with your MySQL username
    password: '', // Replace with your MySQL password
    database: 'noticeboard' // Replace with your database name
});

// Connect to MySQL
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL');
});

// Use cors middleware
app.use(cors());

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(bodyParser.urlencoded({ extended: false }));

// Parse JSON bodies (as sent by API clients)
app.use(bodyParser.json());

// Define the route for handling form submission
app.post('/login', (req, res) => {
    const username = req.body.email_id;
    const password = req.body.password;
    const userType = req.body.user_type;

    // Check if username, password, and user type are provided
    if (username && password && userType) {
        // Query the respective table based on user type
        const tableName = userType === 'teacher' ? 'Teacher' : 'Student';
        const query = `SELECT * FROM ${tableName} WHERE email_id = ? AND password = ?`;
        connection.query(query, [username, password], (err, results) => {
            if (err) {
                console.error('Error executing query:', err);
                res.status(500).send('Internal server error');
                return;
            }
            if (results.length > 0) {
                res.send({ userType: userType });
            } else {
                res.send({ error: 'Invalid credentials' });
            }
        });
    } else {
        res.status(400).send('Please provide username, password, and user type');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
});
